var group__kvlc__memorator =
[
    [ "kvlcFeedLogEvent", "group__kvlc__memorator.html#ga4d7c2457bbfcfc81e0545ec46e2525cb", null ],
    [ "kvlcFeedNextFile", "group__kvlc__memorator.html#ga91ad4e6c63cabf424558c7034f0e1082", null ],
    [ "kvlcFeedSelectFormat", "group__kvlc__memorator.html#ga607112a97a47dc861595b8928f08839f", null ]
];